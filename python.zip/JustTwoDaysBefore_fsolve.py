from scipy.optimize import fsolve

def f(x):
    f=x**2+2*x+1
    return f
    
xg=-3
x=fsolve(f,xg)
print(x)





































