
import numpy
import scipy
from scipy.optimize import fsolve
from scipy.integrate import odeint 

ma=1
mb=2
U=100
P=1
L=10
Tain=400
Tbin=300
n=10
ka=-(U*P/ma)
kb=-(U*P/mb)

def cpa(T):
    f=4000+10*T+0.01*T*T
    return f
def cpadT(T):
    f=4000*T+10*T*T/2+0.01*T*T*T/3
    return f

def cpb(T):
    f=3000+5*T+0.02*T*T
    return f
def cpbdT(T):
    f=3000*T+5*T*T/2+0.02*T*T*T/3
    return f
    
def dtdx(T,x):
    Ta=T[0]
    Tb=T[1]
    dTadx=(ka/cpa(Ta))*(Ta-Tb)
    Ta=Ta+(dTadx*L/n)
    dTbdx=(kb/cpb(Tb))*(Ta-Tb)
    Tb=Tb+(dTbdx*L/n)
    return dTadx,dTbdx

Ta0=Tain
Tb0=Tain-0.0001
Tbn=322
e=Tbn-Tbin

while e<=-0.0001 or e>=0.0001:
    Ta0=Ta0
    Tb0=Tb0
    x=numpy.linspace(0,L,n)
    T0=scipy.array([Ta0,Tb0])
    Tn=odeint(dtdx,T0,x)
    Tan=Tn[0]
    Tbn=Tn[1]
    e=Tbn-Tbin
    if e<=-0.0001 or e>=0.0001:
        Tb0=Tb0+1
    else:
        print("the outlet Tb is ")
        print(Tb0)










































