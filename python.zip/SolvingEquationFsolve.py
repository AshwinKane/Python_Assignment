
import scipy
from scipy.optimize import fsolve

def f(z):
    f1=z[0]+1
    f2=z[0]+z[1]-3
    f3=z[1]+2*z[2]-5
    f=scipy.array([f1,f2,f3])
    return f

z=[1,2,100]
zsoln=fsolve(f,z)
print(zsoln)


































