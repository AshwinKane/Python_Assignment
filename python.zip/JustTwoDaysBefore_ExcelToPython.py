# -*- coding: utf-8 -*-
"""
Created on Sun May 01 20:53:29 2016

@author: ASHWIN KANE
"""

import pandas
import scipy

Excel_File=pandas.read_excel("ExcelProgram.xlsx","Sheet1",header=False,index=False)

a=Excel_File["a"]

print("The file is ")
print(Excel_File)

first_a=scipy.array(a)
print(first_a)

l=len(first_a)
print(l)
dydt_list=[]
b=0
c=1

for i in range(l-1):
    b=b
    c=c
    dydt=a[c]-a[b]
    dydt_list+=[dydt]
    b=b+1
    c=c+1
print(dydt_list)

    



































